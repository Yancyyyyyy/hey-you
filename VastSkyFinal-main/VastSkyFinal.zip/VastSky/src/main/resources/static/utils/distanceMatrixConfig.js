window.addEventListener("load", () => {
    var script = document.createElement("script");
    script.type = "text/javascript";
    script.src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyDuTPbLJXkbdgS6VyX5sP1WqgDapmlLaEs&libraries=geometry&language=ptbr"
    document.body.appendChild(script);
})
