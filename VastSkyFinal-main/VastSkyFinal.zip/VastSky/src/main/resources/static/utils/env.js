const env = {
    test: 'http://localhost:5500/'
}

export default env;