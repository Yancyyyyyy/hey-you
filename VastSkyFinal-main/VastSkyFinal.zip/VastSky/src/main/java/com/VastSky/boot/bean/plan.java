package com.VastSky.boot.bean;

import lombok.Data;

@Data
public class plan {
    private String plan;
}
